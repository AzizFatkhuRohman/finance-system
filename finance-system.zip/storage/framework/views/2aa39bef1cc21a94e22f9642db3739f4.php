<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb -->
    <nav class="hk-breadcrumb" aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-light bg-transparent">
            <li class="breadcrumb-item"><a href="#">Data</a></li>
            <li class="breadcrumb-item active" aria-current="page">Customers</li>
        </ol>
    </nav>
    <!-- /Breadcrumb -->

    <!-- Container -->
    <div class="container-fluid">

        <!-- Title -->
        <div class="hk-pg-header">
            <h4 class="hk-pg-title"><span class="pg-title-icon"><span class="feather-icon"><i
                            data-feather="database"></i></span></span>Customers</h4>
        </div>
        <!-- /Title -->

        <!-- Row -->
        <div class="row">
            <div class="col-xl-12">
                <section class="hk-sec-wrapper">
                    <h5 class="hk-sec-title">Data Customers &nbsp;&nbsp; <a href="<?php echo e(url('customer/create')); ?>"><button
                                class="btn btn-primary btn-sm">Tambah data</button></a>&nbsp;&nbsp;<a href="<?php echo e(url('araging')); ?>"><button
                                    class="btn btn-warning btn-sm">AR Aging</button></a></h5>

                    <p class="mb-40">Untuk berinteraksi dengan para <code>customers</code> bisa melihat beberapa data
                        berikut dan bisa di lihat lebih detail dari tabel customer di bawah ini.</p>
                    <div class="row">
                        <div class="col-sm">
                            <div class="table-wrap">
                                <table id="datable_1" class="table table-hover mb-x0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Kode Customer</th>
                                            <th>Nama PT/CV</th>
                                            <th>Email</th>
                                            <th>Alamat</th>
                                            <th>Option</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $no = 1;
                                        ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($no++); ?></td>
                                                <td><?php echo e($item->code_customer); ?></td>
                                                <td><?php echo e($item->nama_perusahaan); ?></td>
                                                <td><?php echo e($item->email); ?></td>
                                                <td><?php echo e($item->alamat); ?></td>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <a href="<?php echo e(url('customer/' . $item->id)); ?>" class="mr-2"
                                                            data-toggle="tooltip" data-original-title="Edit">
                                                            <i class="icon-pencil"></i>
                                                        </a>
                                                        <form action="<?php echo e(url('customer/' . $item->id)); ?>" method="post"
                                                            id="delete-form-<?php echo e($item->id); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('delete'); ?>
                                                            <button type="button" class="btn btn-sm"
                                                                onclick="Swal.fire({
                                                                title: 'Apakah Anda yakin?',
                                                                text: 'Data ini akan dihapus permanen!',
                                                                icon: 'warning',
                                                                showCancelButton: true,
                                                                confirmButtonText: 'Hapus',
                                                                cancelButtonText: 'Batal',
                                                                reverseButtons: true
                                                            }).then((result) => {
                                                                if (result.isConfirmed) {
                                                                    // Jika user memilih 'Hapus', submit form untuk menghapus data
                                                                    document.getElementById('delete-form-<?php echo e($item->id); ?>').submit();
                                                                }
                                                            });">
                                                                <i class="icon-trash txt-danger" data-toggle="tooltip"
                                                                    data-original-title="Hapus"></i>
                                                            </button>
                                                        </form>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>No</th>
                                            <th>Kode Customer</th>
                                            <th>Nama PT/CV</th>
                                            <th>Email</th>
                                            <th>Alamat</th>
                                            <th>Option</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
        <!-- /Row -->

    </div>
    <!-- /Container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\finance-system-main\finance-system\resources\views/admin/data_customer.blade.php ENDPATH**/ ?>