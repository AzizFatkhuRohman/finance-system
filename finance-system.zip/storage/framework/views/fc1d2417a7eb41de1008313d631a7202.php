<footer class="footer">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <p>costomize by<a href="#" class="text-dark" target="_blank">h3codeverse</a> © 2025</p>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <p class="d-inline-block">Follow us</p>
                            <a href="#" class="d-inline-block btn btn-icon btn-icon-only btn-indigo btn-icon-style-4"><span class="btn-icon-wrap"><i class="fa fa-facebook"></i></span></a>
                            <a href="#" class="d-inline-block btn btn-icon btn-icon-only btn-indigo btn-icon-style-4"><span class="btn-icon-wrap"><i class="fa fa-twitter"></i></span></a>
                            <a href="#" class="d-inline-block btn btn-icon btn-icon-only btn-indigo btn-icon-style-4"><span class="btn-icon-wrap"><i class="fa fa-instagram "></i></span></a>
                        </div>
                    </div>
                </footer><?php /**PATH C:\xampp\htdocs\finance-system-main\finance-system\resources\views/partials/footer.blade.php ENDPATH**/ ?>