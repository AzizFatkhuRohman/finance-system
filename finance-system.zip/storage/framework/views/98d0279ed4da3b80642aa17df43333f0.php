<?php $__env->startSection('content'); ?>
    <nav class="hk-breadcrumb" aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-light bg-transparent">
            <li class="breadcrumb-item"><a href="#">Forms</a></li>
            <li class="breadcrumb-item active" aria-current="page">Form Pengiriman</li>
        </ol>
    </nav>

    <div class="container-fluid">
        <div class="hk-pg-header">
            <h4 class="hk-pg-title">
                <span class="pg-title-icon">
                    <span class="feather-icon"><i data-feather="align-left"></i></span>
                </span>
                Form Pengiriman
            </h4>
        </div>

        <div class="row">
            <div class="col-xl-12">
                <section class="hk-sec-wrapper">
                    <div class="row">
                        <div class="col-sm">
                            <form action="<?php echo e(url('penjualan')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="nama_bank">Nama Customer</label>
                                        <select
                                            class="form-control custom-select-sm <?php $__errorArgs = ['nama_customer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="nama_customer" id="nama_customer" readonly>
                                            <option value="<?php echo e($data->customer_id); ?>"><?php echo e($data->customer->nama_perusahaan); ?>

                                            </option>
                                            <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_perusahaan); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['nama_customer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-lg-6">
                                        <label for="tanggal">Tanggal</label>
                                        <input class="form-control form-control-sm <?php $__errorArgs = ['tgl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="cabang" name="tgl" type="date"
                                            value="<?php echo e($data->tgl_transaksi ?? old('tgl')); ?>" readonly>
                                        <?php $__errorArgs = ['tgl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="nomor_rekening">Alamat Pengiriman</label>
                                        <textarea name="alamat" id="alamat" class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" readonly><?php echo e($data->customer->alamat ?? old('alamat')); ?></textarea>
                                        <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="nama_pemilik">Kode Transaksi</label>
                                        <input type="text" name="kode_transaksi"
                                            class="form-control form-control-sm <?php $__errorArgs = ['kode_transaksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e($data->kode_transaksi); ?>" readonly>
                                        <?php $__errorArgs = ['kode_transaksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <br>
                                <div class="table-wrap">
                                    <table class="table table-hover mb-x0">
                                        <thead>
                                            <tr>
                                                <th>Kode Akun</th>
                                                <th>Produk</th>
                                                <th>Quantity</th>
                                                <th>Harga</th>
                                                <th>Total Harga</th>
                                            </tr>
                                        </thead>
                                        <tbody id="dynamic-rows">
                                            <?php $__currentLoopData = $DetailProdukPenjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penjualan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <select
                                                            class="form-control custom-select-sm <?php $__errorArgs = ['kode_akun.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            name="kode_akun[]">
                                                            <option value="<?php echo e($penjualan->chart_of_account_id); ?>">
                                                                <?php echo e($penjualan->chartOfAccount->no_account); ?></option>
                                                            <?php $__currentLoopData = $kode_akun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($item->id); ?>">
                                                                    <?php echo e($item->no_account); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <?php $__errorArgs = ['kode_akun.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </td>
                                                    <td>
                                                        <select
                                                            class="form-control custom-select-sm <?php $__errorArgs = ['produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            name="produk[]">
                                                            <option value="<?php echo e($penjualan->product_id); ?>">
                                                                <?php echo e($penjualan->product->nama_produk); ?></option>
                                                            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($item->id); ?>"
                                                                    data-harga="<?php echo e($item->harga); ?>">
                                                                    <?php echo e($item->nama_produk); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <?php $__errorArgs = ['produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </td>
                                                    <td><input type="number" name="quantity[]"
                                                            class="form-control form-control-sm <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            value="<?php echo e($penjualan->qty); ?>">
                                                        <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </td>
                                                    <td><input type="text" name="harga[]"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e($penjualan->product->harga); ?>" readonly></td>
                                                    <td><input type="text" name="total_harga[]"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e($penjualan->total_harga); ?>" readonly></td>
                                                    <td><button type="button" class="btn btn-danger btn-sm remove-row"
                                                            id="tombol" hidden><i
                                                                class="icon-trash txt-danger"></i></button></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                    </br>
                                    <button type="button" id="add-row" class="btn btn-success btn-sm" hidden><i
                                            class="icon-plus"> Tambah Produk</i></button>
                                    </br>
                                </div>
                                <div class="table-wrap">
                                    <table class="table table-hover mb-x0">
                                        <thead>
                                            <tr>
                                                <th style="width: 20%;"></th>
                                                <th style="width: 20%;"></th>
                                                <th style="width: 20%;"></th>
                                                <th>Pajak</th>
                                                <th><input type="text" class="form-control form-control-sm"
                                                        value="<?php echo e($data->pajak); ?>" readonly>
                                                </th>
                                            </tr>
                                            <tr>
                                                <th style="width: 20%;"></th>
                                                <th style="width: 20%;"></th>
                                                <th style="width: 20%;"></th>
                                                <th>Diskon</th>
                                                <th><input type="text" class="form-control form-control-sm"
                                                        value="<?php echo e($data->diskon); ?>" readonly>
                                                </th>
                                            </tr>
                                            <tr>
                                                <th style="width: 20%;"></th>
                                                <th style="width: 20%;"></th>
                                                <th style="width: 20%;"></th>
                                                <th><strong>Total</strong></th>
                                                <th><input type="text" name="total"
                                                        class="form-control form-control-sm" readonly></th>
                                            </tr>
                                        </thead>
                                    </table>
                                    </br>
                                </div>
                                <div class="col-xl-4">
                                    <section class="hk-sec-wrapper">
                                        <h5 class="hk-sec-title">File Upload</h5>
                                        <p class="mb-40">upload jika ada lampiran.</p>
                                        <div class="row">
                                            <div class="col-sm">
                                                <div class="fallback">
                                                    <input name="file" type="file" multiple name="file[]" />
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                </div>
                                <button type="submit" class="btn btn-primary btn-sm">Submit</button>
                                
                                <button type="button" class="btn btn-danger btn-sm"
                                    style="float: right;">Delete</button>
                            </form>

                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <script>
        document.getElementById('editButton').addEventListener('click', function() {
            const inputs = document.querySelectorAll('input, textarea, select');
            const tombol = document.getElementById('tombol');
            const addRow = document.getElementById('add-row');

            // Cek apakah sekarang readonly atau tidak
            const isReadonly = inputs[0].hasAttribute('readonly');

            // Aktifkan/Nonaktifkan readonly di input
            inputs.forEach(input => {
                if (input.name !== 'total_harga' && input.name !== 'total') {
                    if (isReadonly) {
                        input.removeAttribute('readonly');
                    } else {
                        input.setAttribute('readonly', true);
                    }
                }
            });

            // Tampilkan/Sembunyikan tombol
            if (isReadonly) {
                tombol.removeAttribute('hidden');
                addRow.removeAttribute('hidden');
            } else {
                tombol.setAttribute('hidden', true);
                addRow.setAttribute('hidden', true);
            }

            // Ubah label tombol edit
            this.textContent = isReadonly ? 'Update' : 'Edit';
        });
    </script>

    <script>
        $(document).ready(function() {
            // Ketika customer dipilih
            $('#nama_customer').on('change', function() {
                var customerId = $(this).val(); // Ambil ID customer yang dipilih

                // Jika ID customer dipilih, kirim request AJAX
                if (customerId) {
                    $.ajax({
                        url: '/customer/' + customerId + '/alamat', // URL untuk mengambil alamat
                        method: 'GET',
                        success: function(response) {
                            if (response.alamat) {
                                // Isi textarea alamat dengan alamat yang diterima dari server
                                $('#alamat').val(response.alamat);
                            } else {
                                // Jika tidak ada alamat, kosongkan textarea
                                $('#alamat').val('');
                            }
                        },
                        error: function(xhr, status, error) {
                            console.log('Error:', error);
                            $('#alamat').val(''); // Kosongkan jika terjadi error
                        }
                    });
                } else {
                    // Jika tidak ada customer yang dipilih, kosongkan alamat
                    $('#alamat').val('');
                }
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            // Ketika produk dipilih
            $('#produk').on('change', function() {
                var productId = $(this).val(); // Ambil ID produk yang dipilih

                // Jika ID produk dipilih, kirim request AJAX untuk mengambil harga dan stok produk
                if (productId) {
                    $.ajax({
                        url: '/produk/' + productId + '/harga',
                        method: 'GET',
                        success: function(response) {
                            if (response.harga) {
                                // Isi textarea alamat dengan alamat yang diterima dari server
                                $('#harga').val(response.harga);
                            } else {
                                // Jika tidak ada harga, kosongkan textarea
                                $('#harga').val('');
                            }
                        },
                        error: function(xhr, status, error) {
                            console.log('Error:', error);
                            $('#harga').val(''); // Kosongkan jika terjadi error
                        }
                    });
                }
            });

            // Ketika quantity diubah
            $('input[name="quantity"]').on('input', function() {
                var harga = $(this).closest('tr').find('input[name="harga"]').val(); // Ambil harga
                var quantity = $(this).val(); // Ambil quantity
                var totalHarga = harga * quantity; // Hitung total harga

                // Tampilkan total harga
                $(this).closest('tr').find('input[name="total_harga"]').val(totalHarga);
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            // Ketika produk dipilih
            $('#dynamic-rows').on('change', 'select[name="produk[]"]', function() {
                var productId = $(this).val(); // Ambil ID produk yang dipilih
                var harga = $(this).find('option:selected').data('harga'); // Ambil harga dari data atribut
                var row = $(this).closest('tr');

                // Isi harga dan hitung total harga berdasarkan quantity
                row.find('input[name="harga[]"]').val(harga);

                var quantity = row.find('input[name="quantity[]"]').val();
                var totalHarga = harga * quantity;
                row.find('input[name="total_harga[]"]').val(totalHarga);
            });

            // Ketika quantity diubah
            $('#dynamic-rows').on('input', 'input[name="quantity[]"]', function() {
                var quantity = $(this).val(); // Ambil quantity
                var harga = $(this).closest('tr').find('input[name="harga[]"]').val(); // Ambil harga
                var totalHarga = harga * quantity; // Hitung total harga
                $(this).closest('tr').find('input[name="total_harga[]"]').val(
                    totalHarga); // Update total harga
            });

            // Menambahkan baris baru
            $('#add-row').on('click', function() {
                const tableBody = $('#dynamic-rows');
                const newRow = $('<tr>');
                newRow.html(`
           <td>
                                                    <select
                                                        class="form-control custom-select-sm <?php $__errorArgs = ['kode_akun.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="kode_akun[]">
                                                        <option value="">Pilih kode akun</option>
                                                        <?php $__currentLoopData = $kode_akun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->no_account); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php $__errorArgs = ['kode_akun.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </td>
                                                <td>
                                                    <select
                                                        class="form-control custom-select-sm <?php $__errorArgs = ['produk.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="produk[]">
                                                        <option selected>Pilih Produk</option>
                                                        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>"
                                                                data-harga="<?php echo e($item->harga); ?>"><?php echo e($item->nama_produk); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php $__errorArgs = ['produk.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </td>
                                                <td><input type="number" name="quantity[]"
                                                        class="form-control form-control-sm <?php $__errorArgs = ['quantity.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        value="">
                                                    <?php $__errorArgs = ['quantity.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </td>
            <td><input type="text" name="harga[]" class="form-control form-control-sm" readonly></td>
            <td><input type="text" name="total_harga[]" class="form-control form-control-sm" readonly></td>
            <td><button type="button" class="btn btn-danger btn-sm remove-row"><i class="icon-trash txt-danger"></i></button></td>
        `);
                tableBody.append(newRow);
            });

            // Menghapus baris
            $('#dynamic-rows').on('click', '.remove-row', function() {
                $(this).closest('tr').remove();
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            // Hitung total harga untuk setiap baris
            $('#dynamic-rows').on('input', 'input[name="quantity[]"], input[name="harga[]"]', function() {
                updateTotal();
            });

            // Hitung total keseluruhan saat pajak atau diskon berubah
            $('input[name="pajak"], input[name="diskon"]').on('input', function() {
                updateTotal();
            });

            // Fungsi untuk menghitung total keseluruhan
            function updateTotal() {
                let totalHarga = 0;

                // Menjumlahkan total harga dari setiap produk
                $('input[name="total_harga[]"]').each(function() {
                    totalHarga += parseFloat($(this).val()) || 0; // Jika kosong, anggap 0
                });

                // Ambil nilai pajak dan diskon
                let pajak = parseFloat($('input[name="pajak"]').val()) || 0; // Default 0 jika kosong
                let diskon = parseFloat($('input[name="diskon"]').val()) || 0; // Default 0 jika kosong

                // Menghitung pajak dan diskon
                let pajakAmount = (pajak / 100) * totalHarga; // Pajak dihitung sebagai persentase
                let diskonAmount = (diskon / 100) * totalHarga; // Diskon dihitung sebagai persentase

                // Hitung total setelah pajak dan diskon
                let grandTotal = totalHarga + pajakAmount - diskonAmount;

                // Masukkan hasil ke dalam input Total
                $('input[name="total"]').val(grandTotal.toFixed(2)); // Menampilkan dengan 2 desimal
            }

            // Inisialisasi hitung total pertama kali jika ada data yang sudah ada
            updateTotal();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\finance-system-main\finance-system\resources\views/admin/form_pengiriman.blade.php ENDPATH**/ ?>