<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb -->
    <nav class="hk-breadcrumb" aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-light bg-transparent">
            <li class="breadcrumb-item"><a href="#">Pages</a></li>
            <li class="breadcrumb-item active" aria-current="page">Penjualan</li>
        </ol>

    </nav>

    <!-- /Breadcrumb -->
    <!-- Container -->
    <div class="container-fluid">
        <!-- Title -->
        <div class="hk-pg-header">
            <h4 class="hk-pg-title"><span class="pg-title-icon"><span class="feather-icon"><i
                            data-feather="layers"></i></span></span>Penjualan</h4>
            <a href="<?php echo e(url('penjualan/create')); ?>"><button class="btn btn-primary btn-sm">Tambah data</button></a>
        </div>

        <!-- /Title -->

        <!-- Row -->
        <div class="row">
            <div class="col-xl-12">
                <section class="hk-sec-wrapper hk-gallery-wrap">
                    <ul class="nav nav-light nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a href="#faktur" class="nav-link" data-toggle="tab">Faktur</a>
                        </li>
                        <!-- <li class="nav-item">
                                            <a href="#invoice" class="nav-link" data-toggle="tab">Invoice</a>
                                        </li> -->
                        <li class="nav-item">
                            <a href="#pengiriman" class="nav-link" data-toggle="tab">Pengiriman</a>
                        </li>
                        <li class="nav-item">
                            <a href="#penawaran" class="nav-link active" data-toggle="tab">Penawaran</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade" id="faktur" role="tabpanel">
                            <div class="row">
                                <div class="col-sm">
                                    </br>
                                    <p class="mb-25">Data pada tabel ini adalah data semua penjualan yang sudah dibayar
                                        oleh customer.</p>
                                    <div class="table-wrap">
                                        <div class="table-responsive-md">
                                            <?php if($faktur): ?>
                                                <table class="table mb-0">
                                                    <thead>
                                                        <tr>
                                                            <th>Kode Transaksi</th>
                                                            <th>Customer</th>
                                                            <th>Date</th>
                                                            <th>Amount</th>
                                                            <th>Status</th>
                                                            <th>Invoice</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__empty_1 = true; $__currentLoopData = $faktur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <tr>
                                                                <td><a
                                                                        href="<?php echo e(url('penjualan/faktur/'.$item->id)); ?>"><?php echo e($item->kode_transaksi); ?></a>
                                                                </td>
                                                                <td><?php echo e($item->customer->nama_perusahaan ?? '-'); ?></td>
                                                                <td>
                                                                    <span class="text-muted">
                                                                        <i class="icon-clock font-13"></i>
                                                                        <?php echo e($item->tgl_transaksi); ?>

                                                                    </span>
                                                                </td>
                                                                <td>Rp. <?php echo e(number_format($item->total_harga, 0, ',', '.')); ?>

                                                                </td>
                                                                <td>
                                                                    <?php if($item->status === 'send'): ?>
                                                                        <div class="badge badge-warning">Unpaid</div>
                                                                    <?php else: ?>
                                                                        <div class="badge badge-success">Paid</div>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td><a href="#">Print</a></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <tr>
                                                                <td colspan="6" class="text-center">Data Faktur Tidak Ada
                                                                </td>
                                                            </tr>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="pengiriman" role="tabpanel">
                            <div class="row">
                                <div class="col-sm">
                                    </br>
                                    <p class="mb-25">Data pada tabel ini adalah data pengiriman.</p>
                                    <div class="table-wrap">
                                        <div class="table-responsive-md">
                                            <?php if($pengiriman): ?>
                                                <table class="table mb-0">
                                                    <thead>
                                                        <tr>
                                                            <th>Kode Transaksi</th>
                                                            <th>Customer</th>
                                                            <th>Date</th>
                                                            <th>Amount</th>
                                                            <th>Status</th>
                                                            <th>Surat Jalan</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__empty_1 = true; $__currentLoopData = $pengiriman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <tr>
                                                                <td><a
                                                                        href="<?php echo e(url('penjualan/pengiriman/'.$item->id)); ?>"><?php echo e($item->kode_transaksi); ?></a>
                                                                </td>
                                                                <td><?php echo e($item->customer->nama_perusahaan ?? '-'); ?></td>
                                                                <td>
                                                                    <span class="text-muted">
                                                                        <i class="icon-clock font-13"></i>
                                                                        <?php echo e($item->tgl_transaksi); ?>

                                                                    </span>
                                                                </td>
                                                                <td>Rp. <?php echo e(number_format($item->total_harga, 0, ',', '.')); ?>

                                                                </td>
                                                                <td>
                                                                    <?php if($item->status === 'created'): ?>
                                                                        <div class="badge badge-warning">Pending</div>
                                                                    <?php else: ?>
                                                                        <div class="badge badge-success">Send</div>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td><a href="#">Print</a></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <tr>
                                                                <td colspan="6" class="text-center">Data Pengiriman Tidak
                                                                    Ada</td>
                                                            </tr>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade show active" id="penawaran" role="tabpanel">
                            <div class="row">
                                <div class="col-sm">
                                    </br>
                                    <p class="mb-25">Data pada tabel ini adalah data penawaran.</p>
                                    <div class="table-wrap">
                                        <div class="table-responsive-md">
                                            <?php if($data): ?>
                                                <table class="table table-hover mb-x0">
                                                    <thead>
                                                        <tr>
                                                            <th>Kode Transaksi</th>
                                                            <th>Customer</th>
                                                            <th>Tanggal</th>
                                                            <th>Total Harga</th>
                                                            <th>Status</th>
                                                            <th>Quatation</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <tr>
                                                                <td><a
                                                                        href="<?php echo e(url('penjualan/spk/' . $item->id)); ?>"><?php echo e($item->kode_transaksi); ?></a>
                                                                </td>
                                                                <td><?php echo e($item->customer->nama_perusahaan ?? '-'); ?></td>
                                                                <td>
                                                                    <span class="text-muted">
                                                                        <i class="icon-clock font-13"></i>
                                                                        <?php echo e($item->tgl_transaksi); ?>

                                                                    </span>
                                                                </td>
                                                                <td>Rp.
                                                                    <?php echo e(number_format($item->total_harga, 0, ',', '.')); ?>

                                                                </td>
                                                                <td>
                                                                    <?php if($item->status === 'draft'): ?>
                                                                        <div class="badge badge-warning">Draft</div>
                                                                    <?php else: ?>
                                                                        <div class="badge badge-success">Created</div>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td><a href="<?php echo e(url('penjualan/quotation')); ?>">Print</a></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <tr>
                                                                <td colspan="6" class="text-center">Data Penawaran Tidak
                                                                    Ada</td>
                                                            </tr>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
        <!-- /Row -->
    </div>
    <!-- /Container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\finance-system-main\finance-system\resources\views/admin/penjualan.blade.php ENDPATH**/ ?>